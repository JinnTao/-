# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

"""
This module is designed to analysis data

"""
